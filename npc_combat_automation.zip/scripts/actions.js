
export async function performAttack(token, target) {
    const attackRoll = new Roll("1d20 + @mod", { mod: token.actor.data.data.attackBonus });
    const rollResult = await attackRoll.roll();
    ChatMessage.create({
        content: `${token.name} attacks ${target.name}: ${rollResult.total}`,
        speaker: { alias: token.name }
    });
}
