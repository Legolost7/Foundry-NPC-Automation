
import { moveToken, calculateOptimalPosition } from "./movement.js";
import { performAttack } from "./actions.js";

Hooks.on("updateCombat", async (combat, updateData, options, userId) => {
    const currentToken = canvas.tokens.get(combat.combatant.tokenId);
    if (currentToken && currentToken.actor.type !== "character") {
        const targets = Array.from(game.user.targets);
        if (targets.length > 0) {
            const optimalPosition = calculateOptimalPosition(currentToken, targets);
            await moveToken(currentToken, optimalPosition);
            await performAttack(currentToken, targets[0]);
        }
    }
});
