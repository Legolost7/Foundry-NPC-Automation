
export async function moveToken(token, targetPosition) {
    const path = canvas.grid.getCenter(token.x, token.y);
    await token.document.update({ x: targetPosition.x, y: targetPosition.y });
}

export function calculateOptimalPosition(token, targets) {
    const target = targets[0];
    return { x: target.x, y: target.y }; // Simplified for MVP
}
